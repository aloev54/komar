"""fontTools.feaLib -- a package for dealing with OpenType feature files."""

# The structure of OpenType feature files is defined here:
# http://www.adobe.com/devnet/opentype/afdko/topic_feature_file_syntax.html
